# Demos

## Videos are available in [drive](https://drive.google.com/open?id=1aomLD0tQJBllB_TsmEUcggex38Rq37L4)

## LIDAR Cone Detection
![Oops](resources/lidar_cones.gif) 

## LOAM
![Oops](resources/loam.gif) 

## ORBSLAM2
![Oops](resources/orbslam.gif) 

## SERVO
![Oops](resources/servo.gif) 

## YOLOv3 Cone Detection
![Oops](resources/yolo.gif) 

## YOLOv3 Cone Tracking
![Oops](resources/tracking.gif) 
